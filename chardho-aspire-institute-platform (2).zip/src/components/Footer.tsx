import Link from "next/link";
import Image from "next/image";
import { SITE_INFO } from "@/lib/site-info";

const COLUMNS = [
  {
    title: "Explore",
    links: [
      { href: "/courses", label: "All Courses" },
      { href: "/categories", label: "Categories" },
      { href: "/placements", label: "Placements" },
      { href: "/about", label: "Our Trainers" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about", label: "About Us" },
      { href: "/contact", label: "Contact" },
      { href: "/placements", label: "Success Stories" },
      { href: "/login", label: "Student Login" },
    ],
  },
  {
    title: "Support",
    links: [
      { href: "/contact", label: "Help Center" },
      { href: "/refund-policy", label: "Refund Policy" },
      { href: "/privacy-policy", label: "Privacy Policy" },
      { href: "/terms-of-service", label: "Terms of Service" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="mt-24 bg-slate-950 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5">
              <Image
                src="/images/logo.png"
                alt="Chardho Aspire Institute"
                width={48}
                height={48}
                className="h-12 w-12 shrink-0 rounded-full object-contain"
              />
              <span>
                <span className="block text-lg font-extrabold text-white">Chardho Aspire Institute</span>
                <span className="block text-[11px] font-semibold tracking-wide text-teal-400">
                  AMBITION · GROWTH · DREAMS
                </span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-400">
              India&apos;s premium AI-powered learning platform. Master in-demand tech skills,
              build real projects, and get placed at top companies.
            </p>
            <div className="mt-5 flex gap-3">
              {["𝕏", "in", "▶", "◎"].map((s) => (
                <span
                  key={s}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-lg bg-white/5 text-sm text-slate-300 transition hover:bg-white/15"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-bold uppercase tracking-wider text-white">{col.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link href={l.href} className="text-sm text-slate-400 transition hover:text-blue-400">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Get in Touch</h4>
            <ul className="mt-4 space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-2">
                <span>📍</span>
                <a
                  href={SITE_INFO.mapsHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition hover:text-blue-400"
                >
                  <address className="not-italic leading-relaxed">
                    {SITE_INFO.addressLines.map((line) => (
                      <span key={line} className="block">
                        {line}
                      </span>
                    ))}
                  </address>
                </a>
              </li>
              <li className="flex items-start gap-2">
                <span>📧</span>
                <a href={`mailto:${SITE_INFO.email}`} className="transition hover:text-blue-400">
                  {SITE_INFO.email}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <span>📞</span>
                <a href={`tel:${SITE_INFO.phoneHref}`} className="transition hover:text-blue-400">
                  {SITE_INFO.phone}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <span>💬</span>
                <a
                  href={SITE_INFO.whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition hover:text-blue-400"
                >
                  WhatsApp: {SITE_INFO.whatsapp}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <span>🕘</span>
                <span>{SITE_INFO.workingHours}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-sm text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} Chardho Aspire Institute. All rights reserved.</p>
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
            <Link href="/privacy-policy" className="transition hover:text-blue-400">Privacy Policy</Link>
            <Link href="/terms-of-service" className="transition hover:text-blue-400">Terms of Service</Link>
            <Link href="/refund-policy" className="transition hover:text-blue-400">Refund Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
