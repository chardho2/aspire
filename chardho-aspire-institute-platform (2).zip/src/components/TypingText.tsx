"use client";

import { useEffect, useState } from "react";

export default function TypingText({ words }: { words: string[] }) {
  const [index, setIndex] = useState(0);
  const [sub, setSub] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[index % words.length];

    if (!deleting && sub === current.length) {
      const t = setTimeout(() => setDeleting(true), 1400);
      return () => clearTimeout(t);
    }

    if (deleting && sub === 0) {
      const t = setTimeout(() => {
        setDeleting(false);
        setIndex((i) => (i + 1) % words.length);
      }, 0);
      return () => clearTimeout(t);
    }

    const t = setTimeout(() => {
      setSub((s) => s + (deleting ? -1 : 1));
    }, deleting ? 45 : 90);
    return () => clearTimeout(t);
  }, [sub, deleting, index, words]);

  return (
    <span className="text-gradient">
      {words[index % words.length].substring(0, sub)}
      <span className="caret font-light text-purple-500">|</span>
    </span>
  );
}
