import { LEARNING_MODES } from "@/lib/site-info";

export default function LearningModes() {
  return (
    <div className="grid gap-6 sm:grid-cols-2">
      {LEARNING_MODES.map((m) => (
        <div
          key={m.key}
          className="group relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-2xl"
        >
          <div
            className={`pointer-events-none absolute -right-10 -top-10 h-36 w-36 rounded-full bg-gradient-to-br ${m.gradient} opacity-10 blur-2xl transition group-hover:opacity-20`}
          />
          <div className="relative flex items-center gap-4">
            <span
              className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${m.gradient} text-3xl text-white shadow-lg`}
            >
              {m.icon}
            </span>
            <div>
              <h3 className="text-xl font-black text-slate-900">{m.title}</h3>
              <p className="text-sm font-semibold text-purple-600">{m.tagline}</p>
            </div>
          </div>
          <p className="relative mt-4 text-sm leading-relaxed text-slate-500">{m.desc}</p>
          <ul className="relative mt-4 space-y-2">
            {m.features.map((f) => (
              <li key={f} className="flex items-center gap-2 text-sm text-slate-600">
                <span className="text-green-500">✓</span>
                {f}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
