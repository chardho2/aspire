import { BATCH_SCHEDULE } from "@/lib/site-info";

export default function BatchSchedule() {
  return (
    <div className="grid gap-5 sm:grid-cols-2">
      {BATCH_SCHEDULE.map((b) => (
        <div
          key={b.title}
          className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
        >
          <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 blur-2xl" />
          <div className="relative flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 text-2xl text-white shadow-lg">
              {b.icon}
            </span>
            <div>
              <h3 className="text-lg font-black text-slate-900">{b.title}</h3>
              <p className="text-xs font-semibold text-purple-600">{b.days}</p>
            </div>
          </div>
          <p className="relative mt-4 inline-flex items-center gap-2 rounded-lg bg-blue-50 px-3 py-1.5 text-sm font-bold text-blue-700">
            🕕 {b.time}
          </p>
          <p className="relative mt-3 text-sm leading-relaxed text-slate-500">{b.desc}</p>
        </div>
      ))}
    </div>
  );
}
