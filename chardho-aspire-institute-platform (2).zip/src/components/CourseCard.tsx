import Link from "next/link";
import type { CourseWithRels } from "@/lib/queries";
import { formatINR, discountPct, formatCount, modeLabel } from "@/lib/format";
import { getAccent } from "@/lib/accent";
import Tilt3D from "./Tilt3D";
import CourseImageSlider from "./CourseImageSlider";

export default function CourseCard({ course }: { course: CourseWithRels }) {
  const off = discountPct(course.price, course.offerPrice);
  const accent = getAccent(course.accent);
  const gallery = course.images.length > 0 ? course.images : course.image ? [course.image] : [];

  return (
    <Tilt3D strength={6} className="h-full">
      <Link
        href={`/courses/${course.slug}`}
        className={`group relative flex h-full flex-col overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm ring-1 ring-transparent transition-all hover:-translate-y-0.5 hover:shadow-2xl hover:${accent.glow} hover:ring-2 hover:${accent.ring}`}
      >
        <CourseImageSlider
          images={gallery}
          alt={course.title}
          gradient={course.gradient}
          emoji={course.emoji}
          heightClass="h-40"
        />

        {course.category && (
          <span className="absolute left-3 top-3 rounded-full bg-white/25 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
            {course.category.icon} {course.category.name}
          </span>
        )}
        {off > 0 && (
          <span className="absolute right-3 top-3 rounded-full bg-white px-2.5 py-1 text-xs font-bold text-purple-600 shadow">
            {off}% OFF
          </span>
        )}

        <div className="flex flex-1 flex-col p-5">
          <h3 className={`text-base font-bold leading-snug text-slate-900 transition-colors group-hover:${accent.text}`}>
            {course.title}
          </h3>
          <p className="mt-1.5 line-clamp-2 flex-1 text-sm text-slate-500">{course.subtitle}</p>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {course.tags.slice(0, 3).map((t) => (
              <span key={t} className={`rounded-md px-2 py-0.5 text-[11px] font-semibold ${accent.badge}`}>
                {t}
              </span>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1 font-semibold text-amber-500">
              ⭐ {Number(course.rating).toFixed(1)}
            </span>
            <span>👥 {formatCount(course.studentsCount)}</span>
            <span>⏱ {course.hours}h</span>
          </div>

          <span className="mt-3 inline-flex w-fit items-center gap-1 rounded-full bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-600">
            {modeLabel(course.mode)}
          </span>

          <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
            <div>
              <span className="text-lg font-extrabold text-slate-900">{formatINR(course.offerPrice)}</span>
              {off > 0 && (
                <span className="ml-2 text-sm text-slate-400 line-through">{formatINR(course.price)}</span>
              )}
            </div>
            <span className={`text-sm font-bold transition group-hover:translate-x-0.5 ${accent.text}`}>
              View →
            </span>
          </div>
        </div>
      </Link>
    </Tilt3D>
  );
}
