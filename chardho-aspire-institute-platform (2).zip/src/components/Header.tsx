"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/courses", label: "Courses" },
  { href: "/categories", label: "Categories" },
  { href: "/placements", label: "Placements" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [prevPathname, setPrevPathname] = useState(pathname);

  // Close the mobile menu whenever the route changes, without a state-updating effect.
  if (pathname !== prevPathname) {
    setPrevPathname(pathname);
    if (open) setOpen(false);
  }

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        setLoggedIn(Boolean(data?.loggedIn));
        setStudentName(data?.name ?? "");
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  const accountHref = loggedIn ? "/dashboard" : "/login";
  const accountLabel = loggedIn ? `👋 ${studentName.split(" ")[0] || "Dashboard"}` : "Login";

  return (
    <header
      className={`sticky top-0 z-50 transition-all ${
        scrolled ? "glass shadow-lg shadow-blue-900/5" : "bg-white/80 backdrop-blur-md"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/images/logo.png"
            alt="Chardho Aspire Institute"
            width={44}
            height={44}
            priority
            className="h-11 w-11 shrink-0 object-contain"
          />
          <span className="leading-tight">
            <span className="block text-[15px] font-extrabold text-slate-900">
              Chardho <span className="text-teal-600">Aspire</span>
            </span>
            <span className="block text-[10px] font-semibold tracking-wide text-slate-400">
              AMBITION · GROWTH · DREAMS
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-lg px-3.5 py-2 text-sm font-semibold transition ${
                  active
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-blue-700"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link
            href={accountHref}
            className="flex items-center gap-1 rounded-lg px-4 py-2 text-sm font-semibold text-slate-700 hover:text-blue-700"
          >
            {loggedIn ? accountLabel : "🧑‍💻 Login"}
          </Link>
          <Link
            href="/courses"
            className="brand-gradient rounded-lg px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.03]"
          >
            Enroll Now
          </Link>
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 lg:hidden"
          aria-label="Toggle menu"
        >
          <span className="text-xl">{open ? "✕" : "☰"}</span>
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-100 bg-white px-4 pb-4 lg:hidden">
          <nav className="flex flex-col gap-1 pt-2">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-lg px-3 py-2.5 text-sm font-semibold ${
                  pathname === item.href ? "bg-blue-50 text-blue-700" : "text-slate-700"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="mt-2 flex gap-2">
              <Link
                href={accountHref}
                className="flex-1 rounded-lg border border-slate-200 px-4 py-2.5 text-center text-sm font-semibold text-slate-700"
              >
                {loggedIn ? accountLabel : "Login"}
              </Link>
              <Link
                href="/courses"
                className="brand-gradient flex-1 rounded-lg px-4 py-2.5 text-center text-sm font-bold text-white"
              >
                Enroll Now
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
