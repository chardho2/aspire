import type { ReactNode } from "react";
import Link from "next/link";

const LEGAL_LINKS = [
  { href: "/privacy-policy", label: "Privacy Policy" },
  { href: "/terms-of-service", label: "Terms of Service" },
  { href: "/refund-policy", label: "Refund Policy" },
];

export default function LegalLayout({
  icon,
  title,
  updated,
  intro,
  children,
}: {
  icon: string;
  title: string;
  updated: string;
  intro: string;
  children: ReactNode;
}) {
  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-purple-700 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <span className="text-5xl">{icon}</span>
          <h1 className="mt-4 text-3xl font-black sm:text-4xl">{title}</h1>
          <p className="mx-auto mt-3 max-w-2xl text-blue-100">{intro}</p>
          <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-blue-200">
            Last updated: {updated}
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:flex">
        <aside className="mb-10 lg:mb-0 lg:w-64 lg:shrink-0">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm lg:sticky lg:top-24">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Legal</h3>
            <ul className="mt-3 space-y-1.5">
              {LEGAL_LINKS.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="block rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-blue-50 hover:text-blue-700"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-4 rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 p-4">
              <p className="text-xs text-slate-500">Have questions about our policies?</p>
              <Link href="/contact" className="mt-1 block text-sm font-bold text-blue-700 hover:underline">
                Contact Support →
              </Link>
            </div>
          </div>
        </aside>

        <article className="max-w-none flex-1 rounded-2xl border border-slate-100 bg-white p-6 shadow-sm sm:p-10">
          {children}
        </article>
      </div>
    </div>
  );
}
