"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/dashboard";
  const [studentCode, setStudentCode] = useState("");

  function goToFaceAuth(e?: React.FormEvent) {
    e?.preventDefault();
    if (!studentCode.trim()) return;
    const params = new URLSearchParams({
      code: studentCode.trim().toUpperCase(),
      redirect: redirectTo,
    });
    router.push(`/login/face?${params.toString()}`);
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="text-center">
        <Image
          src="/images/icon-mark.png"
          alt="Chardho Aspire Institute"
          width={56}
          height={56}
          className="mx-auto h-14 w-14 rounded-2xl object-contain shadow-lg"
        />
        <h1 className="mt-4 text-2xl font-black text-slate-900">Student Sign In</h1>
        <p className="mt-1 text-sm text-slate-500">
          Sign in securely with Face Authentication using your device camera.
        </p>
      </div>

      <form onSubmit={goToFaceAuth} className="mt-8 rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
        <label className="block">
          <span className="mb-1.5 block text-sm font-semibold text-slate-700">Student ID</span>
          <input
            required
            value={studentCode}
            onChange={(e) => setStudentCode(e.target.value)}
            placeholder="e.g. CAI-2026-04821"
            className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm uppercase tracking-wide outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
          />
        </label>

        <button
          type="submit"
          disabled={!studentCode.trim()}
          className="brand-gradient mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-50"
        >
          🧑‍💻 Continue with Face Authentication
        </button>

        <button
          type="button"
          onClick={() => setStudentCode("CAI-2026-04821")}
          className="mt-3 w-full rounded-xl border border-dashed border-slate-200 py-2.5 text-xs font-semibold text-slate-500 transition hover:border-blue-300 hover:text-blue-600"
        >
          Use demo Student ID (CAI-2026-04821)
        </button>
      </form>

      <div className="mt-6 rounded-2xl border border-slate-100 bg-gradient-to-br from-blue-50 to-purple-50 p-5 text-center">
        <p className="text-sm font-semibold text-slate-700">🔒 How Face Authentication works</p>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          Enter your Student ID, then look at your camera. We scan and match your face against
          your enrolled Face ID to grant secure access to your dashboard and digital ID card — no
          password needed.
        </p>
      </div>

      <p className="mt-6 text-center text-sm text-slate-500">
        New here?{" "}
        <Link href="/contact" className="font-bold text-blue-600 hover:underline">
          Talk to admissions
        </Link>{" "}
        to get enrolled and receive your Student ID.
      </p>
    </div>
  );
}

function LoginFallback() {
  return (
    <div className="mx-auto max-w-md animate-pulse">
      <div className="mx-auto h-14 w-14 rounded-2xl bg-slate-200" />
      <div className="mx-auto mt-4 h-6 w-48 rounded bg-slate-200" />
      <div className="mx-auto mt-2 h-4 w-64 rounded bg-slate-200" />
      <div className="mt-8 h-64 rounded-2xl bg-slate-100" />
    </div>
  );
}

export default function LoginPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <Suspense fallback={<LoginFallback />}>
        <LoginForm />
      </Suspense>
    </div>
  );
}
