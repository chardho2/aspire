"use client";

import { useState } from "react";
import BatchSchedule from "@/components/BatchSchedule";
import { SITE_INFO } from "@/lib/site-info";

export default function ContactPage() {
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setForm({ name: "", email: "", subject: "", message: "" });
    } catch {
      setStatus("error");
    }
  }

  const info = [
    { icon: "📞", label: "Customer Care", value: SITE_INFO.phone },
    { icon: "📧", label: "Email us", value: SITE_INFO.email },
    { icon: "🕘", label: "Working Hours", value: SITE_INFO.workingHours },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="text-center">
        <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Contact</span>
        <h1 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Let&apos;s talk about your goals</h1>
        <p className="mx-auto mt-3 max-w-xl text-slate-500">
          Book a free demo, ask about courses, or get a personalized learning roadmap from our team.
        </p>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-5">
        <div className="space-y-4 lg:col-span-2">
          <a
            href={SITE_INFO.mapsHref}
            target="_blank"
            rel="noopener noreferrer"
            className="block rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:border-blue-300 hover:shadow-md"
          >
            <div className="flex items-start gap-4">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 text-xl">
                📍
              </span>
              <div>
                <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">Visit Us</div>
                <div className="mt-0.5 text-sm font-bold text-slate-900">{SITE_INFO.name}</div>
                <address className="mt-1 text-sm not-italic leading-relaxed text-slate-600">
                  {SITE_INFO.addressLines.map((line) => (
                    <span key={line} className="block">
                      {line}
                    </span>
                  ))}
                </address>
                <span className="mt-2 inline-block text-xs font-bold text-blue-600">Get Directions →</span>
              </div>
            </div>
          </a>
          {info.map((i) => (
            <div key={i.label} className="flex items-start gap-4 rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 text-xl">
                {i.icon}
              </span>
              <div>
                <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">{i.label}</div>
                <div className="mt-0.5 text-sm font-semibold text-slate-800">{i.value}</div>
              </div>
            </div>
          ))}
          <a
            href={SITE_INFO.whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="block rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 p-6 text-white shadow-lg transition hover:scale-[1.02]"
          >
            <div className="text-2xl">💬</div>
            <h3 className="mt-2 text-lg font-bold">Chat on WhatsApp</h3>
            <p className="mt-1 text-sm text-green-50">{SITE_INFO.whatsapp} · Instant replies from a counselor.</p>
          </a>
        </div>

        <div className="lg:col-span-3">
          <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm sm:p-8">
            {status === "done" ? (
              <div className="py-12 text-center">
                <div className="text-5xl">✅</div>
                <h3 className="mt-4 text-xl font-bold text-slate-900">Message sent!</h3>
                <p className="mt-2 text-slate-500">Our team will get back to you within 24 hours.</p>
                <button
                  onClick={() => setStatus("idle")}
                  className="mt-6 rounded-xl border border-slate-200 px-6 py-2.5 text-sm font-bold text-slate-700 hover:border-blue-300"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Full name" required>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="input"
                    />
                  </Field>
                  <Field label="Email" required>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="input"
                    />
                  </Field>
                </div>
                <Field label="Subject">
                  <input
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="input"
                  />
                </Field>
                <Field label="Message" required>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="input resize-none"
                  />
                </Field>
                <button
                  disabled={status === "loading"}
                  className="brand-gradient w-full rounded-xl py-3 text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.01] disabled:opacity-60"
                >
                  {status === "loading" ? "Sending..." : "Send Message"}
                </button>
                {status === "error" && (
                  <p className="text-center text-sm font-medium text-red-500">
                    Something went wrong. Please try again.
                  </p>
                )}
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Batch schedule */}
      <div className="mt-16">
        <div className="text-center">
          <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Class Timings</span>
          <h2 className="mt-2 text-2xl font-black text-slate-900 sm:text-3xl">Choose a batch that fits your schedule</h2>
          <p className="mx-auto mt-2 max-w-xl text-slate-500">
            We run both weekday and weekend batches so you can learn at a pace that works for you.
          </p>
        </div>
        <div className="mt-8">
          <BatchSchedule />
        </div>
      </div>

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid #e2e8f0;
          padding: 0.65rem 0.9rem;
          font-size: 0.875rem;
          outline: none;
          transition: all 0.15s;
        }
        :global(.input:focus) {
          border-color: #60a5fa;
          box-shadow: 0 0 0 3px rgba(219, 234, 254, 0.8);
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-slate-700">
        {label} {required && <span className="text-red-500">*</span>}
      </span>
      {children}
    </label>
  );
}
