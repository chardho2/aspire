import type { Metadata } from "next";
import Link from "next/link";
import CourseCard from "@/components/CourseCard";
import { getAllCourses, getCategories } from "@/lib/queries";

export const metadata: Metadata = {
  title: "All Courses",
  description:
    "Explore job-ready courses in web development, AI, cloud, data science, design and more at Chardho Aspire Institute.",
};

export const dynamic = "force-dynamic";

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const { category, q } = await searchParams;
  const [courses, categories] = await Promise.all([getAllCourses(), getCategories()]);

  let filtered = courses;
  if (category) filtered = filtered.filter((c) => c.category?.slug === category);
  if (q) {
    const term = q.toLowerCase();
    filtered = filtered.filter(
      (c) =>
        c.title.toLowerCase().includes(term) ||
        c.subtitle.toLowerCase().includes(term) ||
        c.tags.some((t) => t.toLowerCase().includes(term)),
    );
  }

  const active = categories.find((c) => c.slug === category);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="rounded-3xl bg-gradient-to-br from-blue-600 to-purple-700 px-6 py-12 text-center text-white shadow-xl">
        <h1 className="text-3xl font-black sm:text-4xl">
          {active ? `${active.icon} ${active.name}` : "Explore All Courses"}
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-blue-100">
          {active
            ? active.description
            : "Hand-crafted, industry-relevant programs to launch your tech career."}
        </p>
        <form className="mx-auto mt-6 flex max-w-md gap-2" action="/courses">
          {category && <input type="hidden" name="category" value={category} />}
          <input
            name="q"
            defaultValue={q ?? ""}
            placeholder="Search courses, skills, tags..."
            className="flex-1 rounded-xl border-0 px-4 py-3 text-sm text-slate-900 shadow-inner outline-none"
          />
          <button className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-bold text-white transition hover:bg-slate-800">
            Search
          </button>
        </form>
      </div>

      {/* Category chips */}
      <div className="mt-8 flex flex-wrap gap-2">
        <Link
          href="/courses"
          className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
            !category ? "brand-gradient text-white shadow" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          All
        </Link>
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/courses?category=${c.slug}`}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              category === c.slug
                ? "brand-gradient text-white shadow"
                : "bg-white text-slate-600 hover:bg-slate-100"
            }`}
          >
            {c.icon} {c.name}
          </Link>
        ))}
      </div>

      <p className="mt-8 text-sm font-medium text-slate-500">
        {filtered.length} course{filtered.length !== 1 ? "s" : ""} found
      </p>

      {filtered.length > 0 ? (
        <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <CourseCard key={c.id} course={c} />
          ))}
        </div>
      ) : (
        <div className="mt-12 rounded-2xl border border-dashed border-slate-200 bg-white py-16 text-center">
          <div className="text-5xl">🔍</div>
          <p className="mt-4 font-semibold text-slate-700">No courses match your search.</p>
          <Link href="/courses" className="mt-3 inline-block text-sm font-bold text-blue-600 hover:underline">
            Clear filters →
          </Link>
        </div>
      )}
    </div>
  );
}
