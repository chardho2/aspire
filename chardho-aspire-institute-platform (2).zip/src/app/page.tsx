import Link from "next/link";
import Image from "next/image";
import CourseCard from "@/components/CourseCard";
import TypingText from "@/components/TypingText";
import CountUp from "@/components/CountUp";
import Tilt3D from "@/components/Tilt3D";
import BatchSchedule from "@/components/BatchSchedule";
import LearningModes from "@/components/LearningModes";
import {
  getFeaturedCourses,
  getCategories,
  getTestimonials,
} from "@/lib/queries";
import { partnerSeed } from "@/db/seed-data";
import { SITE_INFO } from "@/lib/site-info";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [courses, categories, testimonials] = await Promise.all([
    getFeaturedCourses(),
    getCategories(),
    getTestimonials(),
  ]);

  const stats = [
    { label: "Students Trained", value: 50000, suffix: "+", icon: "🎓" },
    { label: "Expert-Led Courses", value: 120, suffix: "+", icon: "📚" },
    { label: "Placement Rate", value: 94, suffix: "%", icon: "💼" },
    { label: "Hiring Partners", value: 350, suffix: "+", icon: "🤝" },
  ];

  const whyUs = [
    { icon: "🤖", title: "AI-Powered Learning", desc: "AI tutor, doubt solver, quiz generator and personalized course recommendations." },
    { icon: "👨‍🏫", title: "Industry Mentors", desc: "Learn from engineers at Google, Amazon, Microsoft & top startups." },
    { icon: "💼", title: "Placement Assistance", desc: "Resume building, mock interviews and referrals until you get hired." },
    { icon: "🛠️", title: "Real Projects", desc: "Build a portfolio of production-grade projects, not just tutorials." },
    { icon: "📜", title: "Verified Certificates", desc: "Industry-recognized certificates with QR verification & LinkedIn sharing." },
    { icon: "♾️", title: "Lifetime Access", desc: "Recorded lectures, notes and community access forever." },
  ];

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="animate-blob absolute -left-20 top-0 h-72 w-72 rounded-full bg-blue-300/40 blur-3xl" />
          <div className="animate-blob absolute right-0 top-20 h-80 w-80 rounded-full bg-purple-300/40 blur-3xl [animation-delay:3s]" />
          <div className="animate-blob absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-fuchsia-200/40 blur-3xl [animation-delay:6s]" />
        </div>

        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="animate-fadeup">
            <span className="inline-flex items-center gap-2 rounded-full border border-purple-200 bg-white/70 px-4 py-1.5 text-sm font-semibold text-purple-700 shadow-sm backdrop-blur">
              🚀 New batches starting this month
            </span>
            <h1 className="mt-5 text-4xl font-black leading-[1.1] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              Master the skills for
              <br />
              <TypingText
                words={["Web Development", "AI & Machine Learning", "Cloud & DevOps", "Data Science", "UI/UX Design"]}
              />
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-600">
              India&apos;s premium AI-powered institute. Learn from industry experts, build real
              projects, earn certificates and get placed at top companies.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700">
                💻 Online Classes
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-purple-50 px-3 py-1.5 text-xs font-bold text-purple-700">
                🏫 Offline Classes
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-green-50 px-3 py-1.5 text-xs font-bold text-green-700">
                📅 Weekday &amp; Weekend Batches
              </span>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/courses"
                className="brand-gradient rounded-xl px-7 py-3.5 text-base font-bold text-white shadow-xl shadow-blue-500/30 transition hover:scale-105"
              >
                Enroll Now
              </Link>
              <Link
                href="/contact"
                className="rounded-xl border border-slate-200 bg-white px-7 py-3.5 text-base font-bold text-slate-800 shadow-sm transition hover:border-blue-300 hover:text-blue-700"
              >
                📅 Book Free Demo
              </Link>
            </div>
            <div className="mt-8 flex items-center gap-6 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {["👩‍💻", "🧑‍🎓", "👨‍💼", "👩‍🔬"].map((e) => (
                    <span key={e} className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-slate-100 text-sm">
                      {e}
                    </span>
                  ))}
                </div>
                <span className="font-semibold">50,000+ learners</span>
              </div>
              <div className="flex items-center gap-1 font-semibold text-amber-500">
                ⭐ 4.9 <span className="text-slate-500">(12k reviews)</span>
              </div>
            </div>
          </div>

          <div className="relative animate-fadeup [animation-delay:150ms]">
            <Tilt3D strength={8} className="animate-float glass rounded-3xl p-6 shadow-2xl shadow-purple-900/10">
              <div className="relative h-56 overflow-hidden rounded-2xl [transform:translateZ(20px)]">
                <Image
                  src="https://images.pexels.com/photos/5553954/pexels-photo-5553954.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
                  alt="Students learning together with a laptop"
                  fill
                  priority
                  sizes="(max-width: 1024px) 90vw, 480px"
                  className="object-cover"
                />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 text-center">
                {[
                  { k: "Live", v: "Classes" },
                  { k: "1:1", v: "Mentors" },
                  { k: "AI", v: "Tutor" },
                ].map((x) => (
                  <div key={x.k} className="rounded-xl bg-white/70 py-3">
                    <div className="text-lg font-black text-gradient">{x.k}</div>
                    <div className="text-xs font-medium text-slate-500">{x.v}</div>
                  </div>
                ))}
              </div>
            </Tilt3D>
            <div className="absolute -left-4 top-8 hidden animate-float rounded-2xl bg-white p-3 shadow-xl [animation-delay:1s] sm:block">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🏆</span>
                <div>
                  <div className="text-xs font-bold text-slate-900">Certificate</div>
                  <div className="text-[10px] text-slate-500">Industry recognized</div>
                </div>
              </div>
            </div>
            <div className="absolute -right-2 bottom-10 hidden animate-float rounded-2xl bg-white p-3 shadow-xl [animation-delay:2s] sm:block">
              <div className="flex items-center gap-2">
                <span className="text-2xl">💼</span>
                <div>
                  <div className="text-xs font-bold text-slate-900">Placed @ Google</div>
                  <div className="text-[10px] text-slate-500">₹32 LPA package</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PARTNERS */}
      <section className="border-y border-slate-100 bg-white py-8">
        <p className="mb-6 text-center text-sm font-semibold uppercase tracking-widest text-slate-400">
          Our learners work at
        </p>
        <div className="relative overflow-hidden">
          <div className="animate-marquee flex w-max gap-12 px-6">
            {[...partnerSeed, ...partnerSeed].map((p, i) => (
              <span key={i} className="whitespace-nowrap text-xl font-black text-slate-300">
                {p}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-slate-100 bg-white p-6 text-center shadow-sm transition hover:shadow-lg"
            >
              <div className="text-3xl">{s.icon}</div>
              <div className="mt-2 text-3xl font-black text-gradient sm:text-4xl">
                <CountUp end={s.value} suffix={s.suffix} />
              </div>
              <div className="mt-1 text-sm font-medium text-slate-500">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <SectionHeader
          eyebrow="Explore"
          title="Learn any skill, anytime"
          subtitle="Browse our most popular categories across development, AI, cloud and design."
        />
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categories.slice(0, 8).map((c) => (
            <Link
              key={c.id}
              href={`/courses?category=${c.slug}`}
              className="group rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-xl"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 text-2xl transition group-hover:scale-110">
                {c.icon}
              </div>
              <h3 className="mt-3 text-sm font-bold text-slate-900">{c.name}</h3>
              <p className="mt-1 line-clamp-2 text-xs text-slate-500">{c.description}</p>
            </Link>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link href="/categories" className="text-sm font-bold text-blue-600 hover:underline">
            View all categories →
          </Link>
        </div>
      </section>

      {/* POPULAR COURSES */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeader
          eyebrow="Popular Courses"
          title="Trending programs this season"
          subtitle="Job-ready bootcamps with live classes, real projects and placement support."
        />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((c) => (
            <CourseCard key={c.id} course={c} />
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link
            href="/courses"
            className="inline-block rounded-xl border border-slate-200 bg-white px-8 py-3 text-sm font-bold text-slate-800 shadow-sm transition hover:border-blue-300 hover:text-blue-700"
          >
            Explore all courses →
          </Link>
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeader
            eyebrow="Why Chardho Aspire"
            title="Everything you need to get hired"
            subtitle="A complete ecosystem built to turn learners into professionals."
          />
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {whyUs.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-slate-100 bg-gradient-to-br from-white to-slate-50 p-6 transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 text-2xl shadow-lg">
                  {f.icon}
                </div>
                <h3 className="mt-4 text-lg font-bold text-slate-900">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionHeader
          eyebrow="Success Stories"
          title="Our learners, now professionals"
          subtitle="Real people, real career transformations at world-class companies."
        />
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="flex flex-col rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-xl"
            >
              <div className="flex items-center gap-1 text-amber-400">{"⭐".repeat(t.rating)}</div>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-600">&ldquo;{t.quote}&rdquo;</p>
              <div className="mt-5 flex items-center gap-3 border-t border-slate-100 pt-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-blue-50 to-purple-50 text-xl">
                  {t.avatar}
                </span>
                <div className="flex-1">
                  <div className="text-sm font-bold text-slate-900">{t.name}</div>
                  <div className="text-xs text-slate-500">
                    {t.role} @ {t.company}
                  </div>
                </div>
                {t.package && (
                  <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-bold text-green-600">
                    {t.package}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* LEARNING MODES */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeader
          eyebrow="Learn Your Way"
          title="Online & Offline classes — you choose"
          subtitle="Attend live virtual classes from anywhere, or learn in-person at our Hindupur campus. Every course is available both ways."
        />
        <div className="mt-10">
          <LearningModes />
        </div>
      </section>

      {/* BATCH SCHEDULE */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeader
          eyebrow="Flexible Learning"
          title="Weekday & weekend batches to fit your life"
          subtitle="Whether you're a student or a working professional, we have a batch timing for you."
        />
        <div className="mt-10">
          <BatchSchedule />
        </div>
        <div className="mx-auto mt-6 max-w-2xl rounded-2xl border border-slate-100 bg-white p-5 text-center shadow-sm">
          <p className="text-sm text-slate-500">
            Need help choosing a batch? Call us at{" "}
            <a href={`tel:${SITE_INFO.phoneHref}`} className="font-bold text-blue-600 hover:underline">
              {SITE_INFO.phone}
            </a>{" "}
            or message us on{" "}
            <a
              href={SITE_INFO.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="font-bold text-green-600 hover:underline"
            >
              WhatsApp
            </a>
            . We&apos;re available {SITE_INFO.workingHours}.
          </p>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-8 sm:px-6">
        <div className="brand-gradient relative overflow-hidden rounded-3xl px-6 py-16 text-center shadow-2xl shadow-purple-500/30">
          <div className="pointer-events-none absolute inset-0 opacity-20">
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white blur-2xl" />
            <div className="absolute -bottom-10 right-10 h-40 w-40 rounded-full bg-white blur-2xl" />
          </div>
          <h2 className="relative text-3xl font-black text-white sm:text-4xl">
            Ready to transform your career?
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-blue-50">
            Join 50,000+ learners. Book a free demo class today and get a personalized learning
            roadmap from our experts.
          </p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Link
              href="/courses"
              className="rounded-xl bg-white px-7 py-3.5 text-base font-bold text-purple-700 shadow-lg transition hover:scale-105"
            >
              Browse Courses
            </Link>
            <Link
              href="/contact"
              className="rounded-xl border-2 border-white/70 px-7 py-3.5 text-base font-bold text-white transition hover:bg-white/10"
            >
              Book Free Demo
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <span className="text-sm font-bold uppercase tracking-widest text-purple-600">{eyebrow}</span>
      <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">{title}</h2>
      <p className="mt-3 text-slate-500">{subtitle}</p>
    </div>
  );
}
