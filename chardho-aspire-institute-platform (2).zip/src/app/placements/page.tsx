import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { getTestimonials } from "@/lib/queries";
import { partnerSeed } from "@/db/seed-data";

export const metadata: Metadata = {
  title: "Placements & Success Stories",
  description:
    "94% placement rate. See how Chardho Aspire learners landed jobs at Google, Microsoft, Amazon and more.",
};

const jobs = [
  { role: "Frontend Engineer", company: "Razorpay", location: "Bangalore", type: "Full-time", ctc: "₹18–24 LPA", emoji: "⚛️" },
  { role: "ML Engineer", company: "Microsoft", location: "Hyderabad", type: "Full-time", ctc: "₹26–34 LPA", emoji: "🤖" },
  { role: "DevOps Engineer", company: "Swiggy", location: "Remote", type: "Full-time", ctc: "₹20–28 LPA", emoji: "☁️" },
  { role: "Product Designer", company: "Flipkart", location: "Bangalore", type: "Full-time", ctc: "₹16–22 LPA", emoji: "🎨" },
  { role: "Backend Developer", company: "Zomato", location: "Gurgaon", type: "Full-time", ctc: "₹18–26 LPA", emoji: "🔧" },
  { role: "Data Analyst", company: "Paytm", location: "Noida", type: "Full-time", ctc: "₹12–18 LPA", emoji: "📊" },
];

export const dynamic = "force-dynamic";

export default async function PlacementsPage() {
  const testimonials = await getTestimonials();

  const stats = [
    { v: "94%", l: "Placement Rate" },
    { v: "₹12 LPA", l: "Average Package" },
    { v: "₹34 LPA", l: "Highest Package" },
    { v: "350+", l: "Hiring Partners" },
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-purple-700 py-20 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <h1 className="text-4xl font-black sm:text-5xl">Careers that take off 🚀</h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-blue-100">
            Our dedicated placement cell works with you until you get hired — resume building,
            mock interviews, referrals and more.
          </p>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.l} className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                <div className="text-3xl font-black">{s.v}</div>
                <div className="mt-1 text-sm text-blue-100">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="relative h-72 w-full overflow-hidden rounded-3xl shadow-xl sm:h-96">
          <Image
            src="https://images.pexels.com/photos/7972741/pexels-photo-7972741.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
            alt="Chardho Aspire graduates celebrating with diplomas"
            fill
            sizes="(max-width: 1024px) 100vw, 1152px"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6 text-white">
            <p className="text-2xl font-black">Every batch, new success stories</p>
            <p className="text-sm text-slate-200">94% of our graduates land offers within 90 days.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <h2 className="text-center text-2xl font-black text-slate-900">Trusted by 350+ hiring partners</h2>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {partnerSeed.map((p) => (
            <span key={p} className="rounded-xl border border-slate-100 bg-white px-5 py-2.5 text-sm font-bold text-slate-500 shadow-sm">
              {p}
            </span>
          ))}
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center">
            <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Placement Portal</span>
            <h2 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Latest job openings</h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((j) => (
              <div key={`${j.role}-${j.company}`} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:shadow-xl">
                <div className="flex items-center justify-between">
                  <span className="text-3xl">{j.emoji}</span>
                  <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-bold text-green-600">{j.ctc}</span>
                </div>
                <h3 className="mt-3 text-lg font-bold text-slate-900">{j.role}</h3>
                <p className="text-sm text-purple-600">{j.company}</p>
                <div className="mt-3 flex gap-3 text-xs text-slate-500">
                  <span>📍 {j.location}</span>
                  <span>🕒 {j.type}</span>
                </div>
                <Link
                  href="/dashboard"
                  className="mt-4 block rounded-xl border border-slate-200 py-2 text-center text-sm font-bold text-slate-700 transition hover:border-blue-300 hover:text-blue-700"
                >
                  Apply Now
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="text-center">
          <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Success Stories</span>
          <h2 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Meet our placed learners</h2>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.id} className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-50 to-purple-50 text-xl">
                  {t.avatar}
                </span>
                <div className="flex-1">
                  <div className="font-bold text-slate-900">{t.name}</div>
                  <div className="text-xs text-slate-500">{t.role} @ {t.company}</div>
                </div>
                <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-bold text-green-600">{t.package}</span>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-600">&ldquo;{t.quote}&rdquo;</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
