import type { Metadata } from "next";
import Link from "next/link";
import { getCategories } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Course Categories",
  description: "Browse all learning categories at Chardho Aspire Institute.",
};

export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const categories = await getCategories();
  const groups = new Map<string, typeof categories>();
  for (const c of categories) {
    const arr = groups.get(c.group) ?? [];
    arr.push(c);
    groups.set(c.group, arr);
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="text-center">
        <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Categories</span>
        <h1 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Find your learning path</h1>
        <p className="mx-auto mt-3 max-w-xl text-slate-500">
          From development to design, explore every domain we teach.
        </p>
      </div>

      <div className="mt-12 space-y-12">
        {[...groups.entries()].map(([group, items]) => (
          <div key={group}>
            <h2 className="mb-5 flex items-center gap-2 text-xl font-black text-slate-900">
              <span className="h-6 w-1.5 rounded-full brand-gradient" />
              {group}
            </h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {items.map((c) => (
                <Link
                  key={c.id}
                  href={`/courses?category=${c.slug}`}
                  className="group rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-xl"
                >
                  <div className="flex items-center justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 text-2xl transition group-hover:scale-110">
                      {c.icon}
                    </span>
                    {c.courseCount > 0 && (
                      <span className="rounded-full bg-slate-50 px-2 py-0.5 text-xs font-bold text-slate-500">
                        {c.courseCount} course{c.courseCount !== 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                  <h3 className="mt-3 text-sm font-bold text-slate-900">{c.name}</h3>
                  <p className="mt-1 line-clamp-2 text-xs text-slate-500">{c.description}</p>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
