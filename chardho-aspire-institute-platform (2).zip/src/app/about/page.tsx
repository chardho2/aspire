import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { getInstructors } from "@/lib/queries";
import { formatCount } from "@/lib/format";
import BatchSchedule from "@/components/BatchSchedule";
import LearningModes from "@/components/LearningModes";
import { SITE_INFO } from "@/lib/site-info";

export const metadata: Metadata = {
  title: "About Us & Trainers",
  description:
    "Learn about Chardho Aspire Institute — our mission, values and the industry experts who mentor our students.",
};

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const instructors = await getInstructors();

  const values = [
    { icon: "🎯", title: "Outcome-Driven", desc: "Every course is designed to make you job-ready, not just certified." },
    { icon: "💡", title: "Learn by Doing", desc: "Real projects and hands-on labs from day one." },
    { icon: "🤝", title: "Learner First", desc: "Mentorship, community and support until you succeed." },
    { icon: "🚀", title: "Future Ready", desc: "Curriculum updated for the AI-first world of 2026." },
  ];

  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 to-purple-700 py-20 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <h1 className="text-4xl font-black sm:text-5xl">Empowering the next generation of tech talent</h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-blue-100">
            Chardho Aspire Institute is an AI-powered learning platform on a mission to make
            world-class tech education accessible, practical and career-changing for everyone.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="relative h-72 w-full overflow-hidden rounded-3xl shadow-xl sm:h-96">
          <Image
            src="https://images.pexels.com/photos/8199134/pexels-photo-8199134.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
            alt="Students engaging in a classroom discussion at Chardho Aspire Institute"
            fill
            sizes="(max-width: 1024px) 100vw, 1152px"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6 text-white">
            <p className="text-2xl font-black">Where ambition meets mentorship</p>
            <p className="text-sm text-slate-200">Live classes, real mentors, real outcomes.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <div key={v.title} className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
              <div className="text-3xl">{v.icon}</div>
              <h3 className="mt-3 text-lg font-bold text-slate-900">{v.title}</h3>
              <p className="mt-2 text-sm text-slate-500">{v.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center">
            <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Our Trainers</span>
            <h2 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Learn from the best in the industry</h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {instructors.map((t) => (
              <div key={t.id} className="rounded-2xl border border-slate-100 bg-gradient-to-br from-white to-slate-50 p-6 shadow-sm transition hover:shadow-xl">
                <div className="flex items-center gap-4">
                  <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-100 to-purple-100 text-3xl">
                    {t.avatar}
                  </span>
                  <div>
                    <div className="text-lg font-bold text-slate-900">{t.name}</div>
                    <div className="text-sm text-purple-600">{t.title}</div>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-slate-600">{t.bio}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {t.expertise.map((e) => (
                    <span key={e} className="rounded-md bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700">
                      {e}
                    </span>
                  ))}
                </div>
                <div className="mt-4 flex gap-4 border-t border-slate-100 pt-4 text-xs text-slate-500">
                  <span>⭐ {Number(t.rating).toFixed(1)} rating</span>
                  <span>👥 {formatCount(t.students)} students</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="text-center">
          <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Learn Your Way</span>
          <h2 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Online &amp; Offline classes</h2>
          <p className="mx-auto mt-3 max-w-xl text-slate-500">
            Every course is available both virtually and in-person at our Hindupur campus — pick
            whichever fits your lifestyle.
          </p>
        </div>
        <div className="mt-10">
          <LearningModes />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="text-center">
          <span className="text-sm font-bold uppercase tracking-widest text-purple-600">Flexible Learning</span>
          <h2 className="mt-2 text-3xl font-black text-slate-900 sm:text-4xl">Weekday &amp; weekend batches</h2>
          <p className="mx-auto mt-3 max-w-xl text-slate-500">
            Choose a schedule that fits your life — study during the week or on weekend evenings.
          </p>
        </div>
        <div className="mt-10">
          <BatchSchedule />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <a
          href={SITE_INFO.mapsHref}
          target="_blank"
          rel="noopener noreferrer"
          className="mb-6 flex flex-col items-start gap-4 rounded-3xl border border-slate-100 bg-white p-8 shadow-sm transition hover:border-blue-300 hover:shadow-md sm:flex-row sm:items-center"
        >
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 text-3xl">
            📍
          </span>
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-purple-600">Visit Us</div>
            <div className="mt-1 text-lg font-black text-slate-900">{SITE_INFO.name}</div>
            <address className="mt-1 not-italic leading-relaxed text-slate-600">
              {SITE_INFO.addressLines.map((line) => (
                <span key={line} className="block text-sm">
                  {line}
                </span>
              ))}
            </address>
            <span className="mt-2 inline-block text-sm font-bold text-blue-600">Get Directions →</span>
          </div>
        </a>

        <div className="grid gap-6 rounded-3xl border border-slate-100 bg-white p-8 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
          <ContactStat icon="📧" label="Email" value={SITE_INFO.email} href={`mailto:${SITE_INFO.email}`} />
          <ContactStat icon="📞" label="Customer Care" value={SITE_INFO.phone} href={`tel:${SITE_INFO.phoneHref}`} />
          <ContactStat icon="💬" label="WhatsApp" value={SITE_INFO.whatsapp} href={SITE_INFO.whatsappHref} />
          <ContactStat icon="🕘" label="Working Hours" value={SITE_INFO.workingHours} />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="brand-gradient rounded-3xl px-6 py-14 text-center text-white shadow-xl">
          <h2 className="text-3xl font-black">Want to teach with us?</h2>
          <p className="mx-auto mt-3 max-w-lg text-blue-50">
            Join our network of expert trainers and shape the careers of thousands of learners.
          </p>
          <Link
            href="/contact"
            className="mt-6 inline-block rounded-xl bg-white px-7 py-3 font-bold text-purple-700 transition hover:scale-105"
          >
            Become a Trainer
          </Link>
        </div>
      </section>
    </div>
  );
}

function ContactStat({
  icon,
  label,
  value,
  href,
}: {
  icon: string;
  label: string;
  value: string;
  href?: string;
}) {
  const content = (
    <div className="flex items-start gap-3">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 text-xl">
        {icon}
      </span>
      <div className="min-w-0">
        <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</div>
        <div className="mt-0.5 truncate text-sm font-bold text-slate-800">{value}</div>
      </div>
    </div>
  );

  if (href) {
    return (
      <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="transition hover:opacity-75">
        {content}
      </a>
    );
  }
  return content;
}
