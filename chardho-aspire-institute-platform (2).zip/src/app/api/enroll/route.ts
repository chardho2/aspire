import { db } from "@/db";
import { enrollments } from "@/db/schema";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, phone, goal, courseId, mode } = body ?? {};

    if (!name || !email) {
      return Response.json({ ok: false, error: "Name and email are required." }, { status: 400 });
    }

    const safeMode = mode === "offline" ? "offline" : "online";

    const [row] = await db
      .insert(enrollments)
      .values({
        name: String(name).slice(0, 160),
        email: String(email).slice(0, 200),
        phone: String(phone ?? "").slice(0, 40),
        goal: String(goal ?? "").slice(0, 1000),
        mode: safeMode,
        courseId: typeof courseId === "number" ? courseId : null,
      })
      .returning();

    return Response.json({ ok: true, id: row.id });
  } catch (err) {
    console.error("enroll error", err);
    return Response.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
