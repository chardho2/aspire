export const SITE_INFO = {
  name: "Chardho Aspire Institute",
  email: "support@chardhoaspire.com",
  phone: "+91 9492620142",
  phoneHref: "+919492620142",
  whatsapp: "+91 9492620142",
  whatsappHref: "https://wa.me/919492620142",
  workingHours: "Monday – Saturday | 9:00 AM – 7:00 PM",
  address:
    "27-6-127, Lakshminagar, Muddireddy Palli, Hindupur, Sri Sathya Sai District, Andhra Pradesh – 515201, India",
  addressLines: [
    "27-6-127, Lakshminagar,",
    "Muddireddy Palli,",
    "Hindupur, Sri Sathya Sai District,",
    "Andhra Pradesh – 515201, India.",
  ],
  mapsHref:
    "https://www.google.com/maps/search/?api=1&query=27-6-127+Lakshminagar+Muddireddy+Palli+Hindupur+Andhra+Pradesh+515201",
};

export const BATCH_SCHEDULE = [
  {
    icon: "💼",
    title: "Weekday Batches",
    days: "Monday – Friday",
    time: "Flexible Morning & Evening Slots",
    desc: "Perfect for full-time learners who can dedicate weekday hours to focused, immersive learning.",
  },
  {
    icon: "🌆",
    title: "Weekend Batches",
    days: "Saturday & Sunday",
    time: "Evening Classes · 6:00 PM – 9:00 PM",
    desc: "Ideal for working professionals and college students — keep your weekdays free and learn on weekends.",
  },
];

export const LEARNING_MODES = [
  {
    icon: "💻",
    key: "online",
    title: "Online Classes",
    tagline: "Learn live from anywhere",
    desc: "Join live interactive classes from home via Zoom / Google Meet, with recordings, doubt-solving sessions and full LMS access.",
    features: ["Live virtual classrooms", "Recorded sessions for revision", "Digital notes & assignments", "AI tutor support 24/7"],
    gradient: "from-blue-500 to-indigo-600",
  },
  {
    key: "offline",
    icon: "🏫",
    title: "Offline Classes",
    tagline: "Learn in-person at our campus",
    desc: "Attend hands-on, instructor-led classes at our Hindupur campus with dedicated lab systems, peer learning and in-person mentorship.",
    features: ["In-person classroom training", "Dedicated lab systems", "Face-to-face mentorship", "Campus placement drives"],
    gradient: "from-purple-500 to-fuchsia-600",
  },
];
