import { db } from "@/db";
import { categories, courses, instructors, testimonials, students } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type { Category, Course, Instructor, Testimonial, Student } from "@/db/schema";

export type CourseWithRels = Course & {
  category: Category | null;
  instructor: Instructor | null;
};

export async function getCategories(): Promise<Category[]> {
  return db.select().from(categories).orderBy(categories.name);
}

export async function getTestimonials(): Promise<Testimonial[]> {
  return db.select().from(testimonials);
}

export async function getInstructors(): Promise<Instructor[]> {
  return db.select().from(instructors).orderBy(desc(instructors.students));
}

function join() {
  return db
    .select({ course: courses, category: categories, instructor: instructors })
    .from(courses)
    .leftJoin(categories, eq(courses.categoryId, categories.id))
    .leftJoin(instructors, eq(courses.instructorId, instructors.id));
}

function map(rows: {
  course: Course;
  category: Category | null;
  instructor: Instructor | null;
}[]): CourseWithRels[] {
  return rows.map((r) => ({
    ...r.course,
    category: r.category,
    instructor: r.instructor,
  }));
}

export async function getAllCourses(): Promise<CourseWithRels[]> {
  const rows = await join().orderBy(desc(courses.featured), desc(courses.studentsCount));
  return map(rows);
}

export async function getFeaturedCourses(): Promise<CourseWithRels[]> {
  const rows = await join()
    .where(eq(courses.featured, true))
    .orderBy(desc(courses.studentsCount));
  return map(rows);
}

export async function getCourseBySlug(slug: string): Promise<CourseWithRels | null> {
  const rows = await join().where(eq(courses.slug, slug)).limit(1);
  const mapped = map(rows);
  return mapped[0] ?? null;
}

export async function getRelatedCourses(
  categoryId: number | null,
  excludeSlug: string,
): Promise<CourseWithRels[]> {
  const all = await getAllCourses();
  return all
    .filter((c) => c.slug !== excludeSlug && (categoryId ? c.categoryId === categoryId : true))
    .slice(0, 3);
}

export async function getStudentByCode(studentCode: string): Promise<Student | null> {
  const rows = await db
    .select()
    .from(students)
    .where(eq(students.studentCode, studentCode))
    .limit(1);
  return rows[0] ?? null;
}
